﻿namespace Nez.Particles
{
	public enum ParticleEmitterType
	{
		Gravity,
		Radial
	}
}