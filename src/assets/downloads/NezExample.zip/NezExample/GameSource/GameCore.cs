using GameSource.Scenes;
using Nez;

public class GameCore : Core
{
    override protected void Initialize()
    {
	    base.Initialize();
        Scene = new TestScene();
    }
}