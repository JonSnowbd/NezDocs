﻿using Microsoft.Xna.Framework;
using Nez;
using Nez.Sprites;

namespace GameSource.Scenes
{
    public class TestScene : Scene
    {
        public class LocalRotationComponent : Component, IUpdatable
        {
            const float RotationTotal = 0.35f;
            void IUpdatable.Update()
            {
                Entity.Rotation = Mathf.Sin(Time.TimeSinceSceneLoad) * RotationTotal;
            }
        }
        public override void OnStart()
        {
            base.OnStart();
            ClearColor = new Color(25,20,25);

            var Logo = AddEntity(new Entity("Logo Spinner"));
            Logo.AddComponent(new SpriteRenderer(Content.LoadTexture("Content/Nez.png")));
            Logo.AddComponent(new LocalRotationComponent());
            Logo.Transform.SetScale(8f);

            Camera.Position = Logo.Position;
        }
    }
}
